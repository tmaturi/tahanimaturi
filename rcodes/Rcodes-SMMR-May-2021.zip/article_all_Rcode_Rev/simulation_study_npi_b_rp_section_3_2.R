######## This file presents R code for the simulation study
#### The simulation study is presented in Section 3.2, in the article 'Statistical reproducibility for pairwise t-tests in pharmaceutical research'
#### The outputs of the simulation study are displayed in Figures 1, 2, 3 and 4

#### The first part of the R file presents code for performing the simulation study
#### The second part of the R file presents code for creating figures displaying outcomes of the simulation study

##### PART 1: SIMULATION STUDY CODE

### To run the code, we need to download functions
## to calculate NPI-B-RP (via Algorithm 1, Section 3.1) 
# for the t-test (reproducibility_t_test_finite_slow_max)
# and for the WMT (reproducibility_Wilcoxon_finite_slow_max)
# see file: Algorithm_1.R
## and also the following function (function_cohen_d) which calculates Cohen's d
# (see Section 2.2)

function_cohen_d <- function(data1,data2) {
  x_1 <- mean(data1)
  x_2 <- mean(data2)
  var_1 <- var(data1)
  var_2 <- var(data2)
  coh <- (x_1 - x_2) /sqrt((var_1 + var_2)/2)
  return(coh)
}


# Note: the below simulations works for equal variance upper-sided t-test
simulation_study_normal_two_sample_t_test <- function(n, m1, s1, m2, s2,N) {
  ## Input into distributions the following:
  # n (sample size)
  # m1 and sd1 (mean and sd of the first normal distribution)
  # m2 and sd2 (mean and sd of the second normal distribution)
  # N (how many normal distributions should be generated)
  
  ## 1. Create an empty data.frame in R where we will record the simulation outputs
  distributions <- data.frame(n=integer(),
                              sampled=character(),
                              hypothesis_t=character(),
                              hypothesis_wmt=character(),
                              m1=numeric(),
                              s1=numeric(),
                              m2=numeric(),
                              s2=numeric(),
                              cohen_d=numeric(),
                              p_value_t=numeric(),
                              p_value_wmt=numeric(),
                              npi_min_t=numeric(),
                              npi_mean_t=numeric(),
                              npi_max_t=numeric(),
                              npi_min_wmt=numeric(),
                              npi_mean_wmt=numeric(),
                              npi_max_wmt=numeric(),
                              stringsAsFactors=FALSE)
  
  ## 2. N samples of size n are generated from each of the two chosen normal distributions
  # each column represents a sample
  S1 <- replicate(N,rnorm(n,m1, s1))
  S2 <- replicate(N,rnorm(n,m2, s2))
  
  ## 3. Record whether we sampled under H_0  (m1=m2) or under H_1 (m1>m2)
  if (m1==m2) {
    sampled <- "under H_0"
  } else {
    sampled <- "under H_1" 
  }
  
  ## 4. For each of the N sets of the two generated groups 
  # of data...
  for (i in 1:N) {
    data <- S1[,i]
    data2 <- S2[,i]
    ## ... calculate sample statistics (mean and variance)
    meann <- mean(data) # mean of the first group
    sdd <- sd(data) # mean of the second group
    meann2 <- mean(data2) # variance of the first group
    sdd2 <- sd(data2) # variance of the second group
    
    # ...record Cohen's d value
    d <- function_cohen_d(data,data2)
    # ...record p-value for the t-test (Section 3.2)
    t<- t.test(data, data2, alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
    # ... record p-value for the WMT (Section 3.3)
    wmt <- wilcox.test(data, data2, alternative = "greater", paired = FALSE)$p.value
    # ... calculate NPI-B-RP for the t-test (Algorithm 1), (Section 3.2)
    tt <- reproducibility_t_test_finite_slow_max(data,data2)
    # ... calculate NPI-B-RP for the WMT (Algorithm 1), (Section 3.3)
    ww <- reproducibility_Wilcoxon_finite_slow_max(data,data2)
    
    # ... record whether the null hypothesis is rejected (R) or not-rejected (N) for the t-test
    if (t <=0.05) {
      hyp <- "R"
    } else {
      hyp <- "N"
    }
    
    # ... record whether the null hypothesis is rejected (R) or not-rejected (N) for the WMT
    if (wmt <=0.05) {
      hyp_wmt <- "R"
    } else {
      hyp_wmt <- "N"
    }
    ## Put all recordings in a table, each line stands for one run of the simulations
    new <- c(n,sampled,hyp,hyp_wmt,round(meann,3),round(sdd,3),round(meann2,3),round(sdd2,3),round(d,3),round(t,3),round(wmt,3),round(tt,3),round(ww,3))
    distributions <-rbind(distributions,do.call(data.frame,setNames(as.list(new), names(distributions))))
  }
  return(distributions)
}

#### The following R code performs the simulation study 
## which outputs are displayed in: 
# Figure 1: Simulations under H0: values of NPI-B-RP (minimal, mean and maximal) for the t-test vs p-value (Section 3.2)
# and in Figure 3. Simulations under H0 and H1: values of NPI-B-RP (minimal, mean and maximal) for the t-test vs Cohen’s d (Section 3.2)
# n=6
set.seed(5)
case0_n6 <- simulation_study_normal_two_sample_t_test(6, 0, 1, 0, 1, 2)
# n=10
set.seed(5)
case0_n10 <- simulation_study_normal_two_sample_t_test(10, 0, 1, 0, 1,50)
# n=20
set.seed(5)
case0_n20 <- simulation_study_normal_two_sample_t_test(20, 0, 1, 0, 1,50)

#### The following R code performs the simulation study 
## which outputs are displayed in: 
# Figure 2: Simulations under H1: values of NPI-B-RP (minimal, mean and maximal) for the t-test vs p-value (Section 3.2)
# in Figure 3. Simulations under H0 and H1: values of NPI-B-RP (minimal, mean and maximal) for the t-test vs Cohen’s d (Section 3.2)
# and in Figure 4. Simulations under H1: values of NPI-B-RP (minimal, mean and maximal) for the WMT vs p-value (Section 3.3)
#n=6
set.seed(5)
case1_n6 <- simulation_study_normal_two_sample_t_test(6, 1, 1, 0, 1,50)
# n=10
set.seed(5)
case1_n10 <- simulation_study_normal_two_sample_t_test(10, 1, 1, 0, 1,50)
# n=20
set.seed(5)
case1_n20 <- simulation_study_normal_two_sample_t_test(20, 1, 1, 0, 1,50)

##### PART 2: FIGURES in ggplot2 - CODE
### The following R code creates Figures 1, 2, 3 and 4 (SECTION 3)

#### Before we run the code to create the figures:
### 1. Download ggplot2
library(ggplot2)

### 2. Download tables (which we acquired after performing the simulation study, see code above
# the tables are in data.frame form
# Under H_0: case0_n6, case0_n10, case0_n20 for Figures 1 and 3
## Under H_1: case1_n6, case1_n10, case1_n20 for Figures 2, 3 and 4

#### Now we can create the figures:

### FIGURE 1 + FIGURE 2: Simulations under H_0 and H_1
# values of NPI-B-RP (minimal, mean and maximal) for the t-test vs p-value
## The code to generate these figures is the same, just the input data.frame
# differs

## Create figures for all the sample size (n=6,10,20) and 
# for both simulations under H_0 and H_1:
## First, choose a data.frame
plot_data <- case0_n6 # Figure 1, Subfigures (a)+(b), n=6, under H_0
plot_data <- case0_n10 # Figure 1, Subfigures (c)+(d), n=10, under H_0
plot_data <- case0_n20 # Figure 1, Subfigures (e)+(f), n=20, under H_0
plot_data <- case1_n6 # Figure 2, Subfigures (a)+(b), n=6, under H_1
plot_data <- case1_n10 #Figure 2, Subfigures (c)+(d), n=10, under H_1
plot_data <- case1_n20 #Figure 2, Subfigures (e)+(f), n=20, under H_1

# Then for each of the above data.frames, run the following two R codes to create ggplots:

# For both rejection and non-rejections cases: subfigures (a),(c),(e) (in Both Figure 1 and 2)
ggplot(plot_data, aes(x=p_value_t, y=npi_mean_t,colour=as.factor(hypothesis_t)))+ 
  geom_errorbar(aes(ymin=npi_min_t, ymax=npi_max_t), width=.01) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab(bquote(paste(italic(p),"-value"))) +
  ylab("NPI-B-RP for t-test") +
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="black", linetype = "dotted") +
  xlim(0,1)+
  ylim(0.27,1)+
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  scale_color_manual(name="Hypothesis",
                     values=c("N"="#0072B2",
                              "R"="orangered1"),
                     labels=c("Not rejected", "Rejected"))

# For only rejection cases: subfigures (b),(d),(f) (in Both Figure 1 and 2)
ggplot(plot_data, aes(x=p_value_t, y=npi_mean_t,colour=as.factor(hypothesis_t)))+ 
  geom_errorbar(aes(ymin=npi_min_t, ymax=npi_max_t), width=.001) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab(bquote(paste(italic(p),"-value"))) +
  ylab("NPI-B-RP for t-test") +
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="black", linetype = "dotted") +
  xlim(0,0.05)+
  ylim(0.27,1)+
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  scale_color_manual(name="Hypothesis",
                     values=c("N"="#0072B2",
                              "R"="orangered1"),
                     labels=c("Not rejected", "Rejected"))


### FIGURE 3: Simulations under H_0 and H_1:
# values of NPI-B-RP (minimal, mean and maximal) for the t-test vs
# Cohen’s d
## We will need data.frames that were already uploaded for Figures 1 and 2
plot_data <- case0_n6 # Subfigure (a), n=6, under H_0
plot_data <- case0_n10 # Subfigure (c), n=10, under H_0
plot_data <- case0_n20 # Subfigure (e), n=20, under H_0
plot_data <- case1_n6 # Subfigure (b), n=6, under H_1
plot_data <- case1_n10 # Subfigure (d), n=10, under H_1
plot_data <- case1_n20 # Subfigure (f), n=20, under H_1

# Then for each of the above data.frames, run the following R code:
ggplot(plot_data, aes(x=cohen_d, y=npi_mean_t,colour=as.factor(hypothesis_t)))+ 
  geom_errorbar(aes(ymin=npi_min_t, ymax=npi_max_t), width=.01) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab(bquote(paste("Cohen's ",italic(d))))+
  ylab("NPI-B-RP for t-test") +
  theme_bw() +
  xlim(-3,6.5)+
  ylim(0.27,1)+
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  scale_color_manual(name="Hypothesis",
                     values=c("N"="#0072B2",
                              "R"="orangered1"),
                     labels=c("Not rejected", "Rejected"))

### FIGURE 4: Simulations under H_1: values of NPI-B-RP 
# (minimal, mean and maximal) 
# for the WMT vs p-value

## We will need data.frames that were already uploaded for Figure 2
plot_data <- case1_n6 # Subfigures (a)+(b), n=6, under H_1
plot_data <- case1_n10 # Subfigures (c)+(d), n=10, under H_1
plot_data <- case1_n20 # Subfigures (d)+(f), n=20, under H_1

## Then for each of the above data.frames, run the following two R codes:
# For both rejection and non-rejections cases: subfigures (a),(c),(e) 
ggplot(plot_data, aes(x=p_value_wmt, y=npi_mean_wmt,colour=as.factor(hypothesis_wmt)))+ 
  geom_errorbar(aes(ymin=npi_min_wmt, ymax=npi_max_wmt), width=.01) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab(bquote(paste(italic(p),"-value for WMT"))) +
  ylab("NPI-B-RP for WMT") +
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="black", linetype = "dotted") +
  xlim(0,1)+
  ylim(0.27,1)+
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  scale_color_manual(name="Hypothesis",
                     values=c("N"="#0072B2",
                              "R"="orangered1"),
                     labels=c("Not rejected", "Rejected"))

# For only rejection cases: subfigures (b),(d),(f) 
ggplot(plot_data, aes(x=p_value_wmt, y=npi_mean_wmt,colour=as.factor(hypothesis_wmt)))+ 
  geom_errorbar(aes(ymin=npi_min_wmt, ymax=npi_max_wmt), width=.001) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab(bquote(paste(italic(p),"-value"))) +
  ylab("NPI-B-RP for WMT") +
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="black", linetype = "dotted") +
  xlim(0,0.05)+
  ylim(0.27,1)+
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  scale_color_manual(name="Hypothesis for WMT",
                     values=c("N"="#0072B2",
                              "R"="orangered1"),
                     labels=c("Not rejected", "Rejected"))
