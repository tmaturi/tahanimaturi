######## This file presents R code for Algorithm 2
#### presented in Section 5.1, in the article 'Statistical reproducibility for pairwise t-tests in pharmaceutical research'

#### The below function calculated reproducibility of the final decision
### This function is applied to the pharmaceutical test scenario dataset 
# (Section 5.1: Table 3, Figures 8 and 9)
# the input into the function are datasets for dose 1, dose 2, dose 3, dose 4, dose 5 and dose 6
# Since in the original test, we run 5 tests simultaneously, we adjust the p-values for multiple testing
# using the Benjamini & Hochberg (1995) procedure

# The below function carries out Algorithm 2 
function_all_combinations_comparison_matrix_t_test_max <- function(dose1,dose2,dose3,dose4,dose5,dose6) {
  n <- length(dose1) # calculate sample size of dose 1
  dose1 <- sort(dose1) # sort data in increasing order for dose 1
  # Record all distances between adjacent points for dose 1
  avl <- vector()
  for (k in (1:(n-1))) {
    avl1 <- dose1[(k+1)] - dose1[k]
    avl <- c(avl,avl1)
  }
  max1 <- max(avl) # Record maximal distance between adjacent points for dose 1
  
  n2 <- length(dose2) # calculate sample size of dose 2
  dose2 <- sort(dose2) # sort data in increasing order for dose 2
  # Record all distances between adjacent points for dose 2
  avl2 <- vector()
  for (k in (1:(n2-1))) {
    avl_2 <- dose2[(k+1)] - dose2[k]
    avl2 <- c(avl2,avl_2)
  }
  max2 <- max(avl2) # Record maximal distance between adjacent points for dose 2
  
  n3 <- length(dose3) # calculate sample size of dose 3
  dose3 <- sort(dose3) # sort data in increasing order for dose 3
  # Record all distances between adjacent points for dose 3
  avl3 <- vector()
  for (k in (1:(n3-1))) {
    avl_3 <- dose3[(k+1)] - dose3[k]
    avl3 <- c(avl3,avl_3)
  }
  max3 <- max(avl3) # Record maximal distance between adjacent points for dose 3
  
  n4 <- length(dose4) # calculate sample size of dose 4
  dose4 <- sort(dose4) # sort data in increasing order for dose 4
  # Record all distances between adjacent points for dose 4
  avl4 <- vector()
  for (k in (1:(n4-1))) {
    avl_4 <- dose4[(k+1)] - dose4[k]
    avl4 <- c(avl4,avl_4)
  }
  max4 <- max(avl4) # Record maximal distance between adjacent points for dose 4
  
  n5 <- length(dose5) # calculate sample size of dose 5
  dose5 <- sort(dose5) # sort data in increasing order for dose 5
  # Record all distances between adjacent points for dose 5
  avl5 <- vector()
  for (k in (1:(n5-1))) {
    avl_5 <- dose5[(k+1)] - dose5[k]
    avl5 <- c(avl5,avl_5)
  }
  max5 <- max(avl5) # Record maximal distance between adjacent points for dose 5
  
  n6 <- length(dose6) # calculate sample size of dose 6
  dose6 <- sort(dose6) # sort data in increasing order for dose 6
  # Record all distances between adjacent points for dose
  avl6 <- vector()
  for (k in (1:(n6-1))) {
    avl_6 <- dose6[(k+1)] - dose6[k]
    avl6 <- c(avl6,avl_6)
  }
  max6 <- max(avl6) # Record maximal distance between adjacent points for dose 6
  
  so1 = min(dose1)-max1 # Defines x_0 for dose 1 
  sn1 = max(dose1)+max1 # Defines x_{n+1} for dose 1
  so2 = min(dose2)-max2 # Defines x_0 for dose 2
  sn2 = max(dose2)+max2 # Defines x_{n+1} for dose 2
  so3 = min(dose3)-max3 # Defines x_0 for dose 3
  sn3 = max(dose3)+max3 # Defines x_{n+1} for dose 3
  so4 = min(dose4)-max4 # Defines x_0 for dose 4 
  sn4 = max(dose4)+max4 # Defines x_{n+1} for dose 4
  so5 = min(dose5)-max5 # Defines x_0 for dose 5
  sn5 = max(dose5)+max5 # Defines x_{n+1} for dose 5
  so6 = min(dose6)-max6 # Defines x_0 for dose 6
  sn6 = max(dose6)+max6 # Defines x_{n+1} for dose 6
  first <- matrix(NA, nrow=1,ncol=10)
  for (i in 1:10) { # note: 10 can be changed into a different number, depending on how many outputs we wants
    finite_slow_npi <- function(x,s0=-Inf,sn=Inf,m,B) { # This function creates B bootstrap sample
      xx <- sort(c(s0,x,sn)) # now it contains min and max point # could add error checking to ensure s0<=min(x) && sn>=max(x)
      n <- length(xx) 
      lb <- matrix(c(xx[1:(n-1)],rep(NA,m)),B,n-1+m,byrow=TRUE) # interval lower bound
      w <- matrix(c(xx[2:n]-xx[1:(n-1)],rep(NA,m)),B,n-1+m,byrow=TRUE) # interval width
      ii <- matrix(1:B,B,2)
      for (j in 1:m) {# this cycle at one go generates step by step all B bootstrap values
        ii[,2] <- sample(n-2+j,B,replace=TRUE) # sample an interval B times (i.e. the start of the interval)
        z <- runif(B) # sample uniformly B values from 0 to 1
        lb[,n-1+j] <- lb[ii]+z*w[ii] # calculate the value: the start of the interval + the width of the interval*z \in (0,1)
        w[,n-1+j] <- (1-z)*w[ii] # new interval added in  
        w[ii] <- z*w[ii] # new width added in 
      }
      return(lb[,n:ncol(lb)])
    }
    # Calculate how many new points should be created for each dose
    m1 <- length(dose1) # calculate sample size of dose 1
    m2 <- length(dose2) # calculate sample size of dose 2
    m3 <- length(dose3) # calculate sample size of dose 3
    m4 <- length(dose4) # calculate sample size of dose 4
    m5 <- length(dose5) # calculate sample size of dose 5
    m6 <- length(dose6) # calculate sample size of dose 6
    # create new set of data points for each dose N (1000) times
    new_d1 <- finite_slow_npi(dose1,so1,sn1,m1,1000)
    new_d2 <- finite_slow_npi(dose2,so2,sn2,m2,1000)
    new_d3 <- finite_slow_npi(dose3,so3,sn3,m3,1000)
    new_d4 <- finite_slow_npi(dose4,so4,sn4,m4,1000)
    new_d5 <- finite_slow_npi(dose5,so5,sn5,m5,1000)
    new_d6 <- finite_slow_npi(dose6,so6,sn6,m6,1000)
    # Create an empty matrix in which you will record the findigs each time
    total_conclusion <- matrix(NA,1,5)
    for (i in 1:1000) {
      # each time do the pairwise comparisons for the bootstrapped samples
      p1 <- t.test(new_d1[i,], new_d2[i,],alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
      p2 <- t.test(new_d2[i,],new_d3[i,], alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
      p3 <- t.test(new_d3[i,],new_d4[i,], alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
      p4 <- t.test(new_d4[i,],new_d5[i,], alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
      p5 <- t.test(new_d5[i,],new_d6[i,], alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value
      # collect the p values in a vector p.raw
      p.raw_wilcox <- c(p1, p2, p3, p4, p5)
      # Since we run 5 tests simultaneously, we adjust the p-values for multiple testing
      # using the Benjamini & Hochberg (1995) procedure
      # and see whether it is below 0.05 or not
      conclusion <- p.adjust(p.raw_wilcox, method = "BH", n = length(p.raw_wilcox)) < 0.05 
      conclusion <- matrix(conclusion,1,5) # collect in a vector (in a matrix form)
      total_conclusion <-rbind(total_conclusion,conclusion) # Each time, add a line to our matrix, recording results from each attempt
    }
    total_conclusion <- total_conclusion[-1,] # remove the first line (which is not needed)
    # Create a frequency table of all the possible combinations of test outcomes recorded in Step 3 of Algorithm 2 
    total <- apply(total_conclusion, 1, function(x) paste(x, collapse=".")  ) 
    kk <- sort(table(total)) 
    print(kk)
  }
}

###### FIGURES 8 and 9

### The below lines show how we applied the above function in Section 5.1 and 5.2 of the article
### First, download, test scenario log transformed data for each dose
doseA <- c(0.7450424, 0.7512600, 0.8483825, 0.8584495, 0.8718323, 0.8963715, 0.9052952, 1.0980984)
doseB <- c(0.5148428, 0.5279702, 0.5545687, 0.5553257, 0.6265338, 0.6314570, 0.6890239, 0.7604780, 0.7843115, 0.8173450)
doseC <- c(0.1087923, 0.1732434, 0.1896337, 0.2202253, 0.2352127, 0.2696757, 0.3298017, 0.4149733, 0.4234364, 0.4400633)
doseD <- c(0.01326204, 0.02647484, 0.03015225, 0.04441902, 0.08823357, 0.14612804, 0.15456121, 0.15848764, 0.26379721)
doseE <- c(-0.12207203, -0.10097169, -0.05188694, -0.04358039, -0.01997116, -0.01820177, -0.01042338, 0.08786727, 0.13904684, 0.19453321)
doseF <- c(-0.194574589, -0.051951545, -0.041698493, -0.003877704,  0.007553198,  0.019622188, 0.051152522, 0.153976971, 0.224668742)
## For the modified datasets # used in Section 5.2
doseD_adjusted <- c(0.4032935, 0.4087244, 0.4102532, 0.4162563, 0.4354103, 0.4623980, 0.4664896, 0.4684086, 0.5231845)

### Then apply Algorithm 2 to the test scenario dataset
# Repr Tree - Table 3 and Figure 8 (Section 5.1)
set.seed(10)
function_all_combinations_comparison_matrix_t_test_max(doseA,doseB,doseC,doseD,doseE,doseF)
# Repr Tree - modified data for dose D (D', viz Figure 5) - Figure 9 (Section 5.2)
set.seed(10)
function_all_combinations_comparison_matrix_t_test_max(doseA,doseB,doseC,doseD_adjusted,doseE,doseF)