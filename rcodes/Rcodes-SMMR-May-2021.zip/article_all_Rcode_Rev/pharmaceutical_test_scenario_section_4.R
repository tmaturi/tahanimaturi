######## This file presents R code for applying Algorithm 1 to
#### the pharmaceutical test scenario and exploring its outcomes
#### The code relates to Section 4, in the article 'Statistical reproducibility for pairwise t-tests in pharmaceutical research'

#### The first part of the R file presents the test scenario data and code for its visualisation (Table 1 and Figure 5)
#### Second part presents lines which calculate all results in Table 2, Section 4.2
### And third part presents code for creating figures displaying outcomes of the pharmaceutical test scenario

### Download package ggplot2
library(ggplot2)

### !! To run the code for SECTION 2, we need to download functions
## to calculate NPI-B-RP (via Algorithm 1, Section 3.1) 
# for the t-test (reproducibility_t_test_finite_slow_max)
# and for the WMT (reproducibility_Wilcoxon_finite_slow_max)
# see file: Algorithm_1.R


###### PART 1: TEST SCENARIO DATASET (Section 4.1)
## note: includes modified dataset # used in Section 5.2

### TABLE 1: DATASET - Test scenario log transformed data for each dose
doseA <- c(0.7450424, 0.7512600, 0.8483825, 0.8584495, 0.8718323, 0.8963715, 0.9052952, 1.0980984)
doseB <- c(0.5148428, 0.5279702, 0.5545687, 0.5553257, 0.6265338, 0.6314570, 0.6890239, 0.7604780, 0.7843115, 0.8173450)
doseC <- c(0.1087923, 0.1732434, 0.1896337, 0.2202253, 0.2352127, 0.2696757, 0.3298017, 0.4149733, 0.4234364, 0.4400633)
doseD <- c(0.01326204, 0.02647484, 0.03015225, 0.04441902, 0.08823357, 0.14612804, 0.15456121, 0.15848764, 0.26379721)
doseE <- c(-0.12207203, -0.10097169, -0.05188694, -0.04358039, -0.01997116, -0.01820177, -0.01042338, 0.08786727, 0.13904684, 0.19453321)
doseF <- c(-0.194574589, -0.051951545, -0.041698493, -0.003877704,  0.007553198,  0.019622188, 0.051152522, 0.153976971, 0.224668742)
## For the modified datasets # used in Section 5.2
doseD_adjusted <- c(0.4032935, 0.4087244, 0.4102532, 0.4162563, 0.4354103, 0.4623980, 0.4664896, 0.4684086, 0.5231845)

### FIGURE 5: Visualisation of test scenario log transformed data for each dose
## note 1: indication of the outcome of pairwise comparison between adjacent doses
## has been added in Preview
## note 2: plot includes the adjusted data for dose D:

# First, create a data.frame
data_doses_article_with_adjusted_dose <- data.frame("Dose" = c(rep(1,8),rep(2,10),rep(3,10),rep(4,9),rep(5,10),rep(6,9), rep(7,9)), "value" = c(doseA,doseB,doseC,doseD,doseE,doseF, doseD_adjusted))

### Plot that includes the adjusted data for dose D:
ggplot(data_doses_article_with_adjusted_dose, aes(x=factor(Dose), y=value)) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab("Dose") +
  ylab("Recorded logged data") +
  scale_colour_hue(l=75) +                    # Use darker colors, lightness=40
  theme_bw() +
  geom_vline(xintercept=6.5,linetype="dashed", 
             color = "blue", size=1) +
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+ #top, right, bottom, left
  scale_x_discrete(labels=c("1"="A","2"="B","3"="C","4"="D","5"="E","6"="F","7"="D'"))


###### PART 2: TABLE 2 (Section 4.2)

### Apply Algorithm 1 to the dataset, to adjacent doses
### Table 2 (Section 4.2): Algorithm 1 outputs
# t-test
reproducibility_t_test_finite_slow_max(doseA, doseB)
reproducibility_t_test_finite_slow_max(doseB, doseC)
reproducibility_t_test_finite_slow_max(doseC, doseD)
reproducibility_t_test_finite_slow_max(doseD, doseE)
reproducibility_t_test_finite_slow_max(doseE, doseF)

# WMT
reproducibility_Wilcoxon_finite_slow_max(doseA, doseB)
reproducibility_Wilcoxon_finite_slow_max(doseB, doseC)
reproducibility_Wilcoxon_finite_slow_max(doseC, doseD)
reproducibility_Wilcoxon_finite_slow_max(doseD, doseE)
reproducibility_Wilcoxon_finite_slow_max(doseE, doseF)

### Table 2 (Section 4.2): calculate statistics of the original data

## Carry out $t$-test, collect p-values and note whether H_0 rejected:
t.test(doseA, doseB, alternative = ("greater"), paired = FALSE, var.equal = TRUE)
t.test(doseB, doseC, alternative = ("greater") ,paired = FALSE, var.equal = TRUE)
t.test(doseC, doseD,alternative = ("greater"), paired = FALSE, var.equal = TRUE)
t.test(doseD, doseE, alternative = ("greater"), paired = FALSE, var.equal = TRUE)
t.test(doseE,doseF, alternative = ("greater"), paired = FALSE, var.equal = TRUE)

## collect the p-values manually in a vector p.raw
p.raw <- c(0.0002764, 5.476e-07, 0.0007448, 0.01914, 0.5977)

## Calculate Cohen's d:
### download function function_cohen_d
# (x_1 - x_2)/sqrt((sigma_1^2 + sigma_2^2)/2)
function_cohen_d <- function(data1,data2) {
  x_1 <- mean(data1)
  x_2 <- mean(data2)
  var_1 <- var(data1)
  var_2 <- var(data2)
  coh <- (x_1 - x_2) /sqrt((var_1 + var_2)/2)
  return(coh)
}

function_cohen_d(doseA,doseB)
# 2.040738
function_cohen_d(doseB,doseC)
# 3.212717 
function_cohen_d(doseC,doseD)
# 1.75344
function_cohen_d(doseD,doseE)
# 1.038011
function_cohen_d(doseE,doseF)
# -0.114933

## Calculate raw ES:
# Raw effect size: 
mean(doseA)-mean(doseB) # For doseA versus doseB 
# 0.2256558
mean(doseB)-mean(doseC) # For doseB versus doseC 
# 0.3656799
mean(doseC)-mean(doseD) # For doseC versus doseD
# 0.1776707
mean(doseD)-mean(doseE) # For doseD versus doseE
# 0.0974011
mean(doseE)-mean(doseF) # For doseE versus doseF
# -0.01288504

###### PART 3: FIGURES 6 and 7 (Section 4.2)
### FIGURE 6: This figure contains 3 subfigures:

## Data.frame needed for Figures 6a), 6b) and 6c):
pairwise_data<- data.frame("Pairwise" = c(1,2,3,4,5), "Compare" = c("A vs. B","B vs. C","C vs. D","D vs. E","E vs. F"),"NPI_B_RP_t" = c(0.937,1.000,0.880,0.586,0.911), ytmin = c(0.917,0.999,0.841,0.552,0.885), ytmax = c(0.954,1.000,0.904,0.622,0.928), "NPI_B_RP_w" = c(0.850,0.959,0.762,0.553,0.936), yvmin = c(0.822,0.941,0.724,0.514,0.918), yvmax = c(0.881,0.969,0.789,0.581,0.952), "Cohen_d" = c(2.041,3.213,1.753, 1.038,-0.115), "logged_pvalue" = c(-3.5584620, -6.2615366, -3.1279603, -1.7180581, -0.2235167), p_value = c(0.0003,0.0000,0.0007,0.0191,0.5977)) #0.5977

### FIGURE 6a) NPI-B-RP for t-test vs p-value

ggplot(pairwise_data, aes(x=p_value, y=NPI_B_RP_t,label=Compare)) + 
  geom_errorbar(aes(ymin=ytmin, ymax=ytmax), width=.01) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab("p-value for t-test") +
  ylab("NPI-B-RP for t-test") +
  ylim(0.5,1.1)+
  xlim(0,1)+
  scale_colour_hue(l=40) + 
  geom_text(hjust=-0.2, vjust=-.3,size=4)+# Use darker colors, lightness=40
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="red",linetype = "dotted")+
  theme(axis.text.x = element_text(color = "grey20", size = 20, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 20, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 22, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 22, angle = 90, hjust = .5, vjust = .5, face = "plain"))

### FIGURE 6b) NPI-B-RP for t-test vs p-value (focus on rejection cases)

ggplot(pairwise_data, aes(x=p_value, y=NPI_B_RP_t,label=Compare)) + 
  geom_errorbar(aes(ymin=ytmin, ymax=ytmax), width=.001) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab("p-value for t-test") +
  ylab("NPI-B-RP for t-test") +
  ylim(0.5,1.1)+
  xlim(0,0.05)+
  scale_colour_hue(l=40) + 
  geom_text(hjust=-0.2, vjust=-.3,size=4)+# Use darker colors, lightness=40
  theme_bw() +
  geom_vline(xintercept = 0.05,colour="red",linetype = "dotted")+
  theme(axis.text.x = element_text(color = "grey20", size = 20, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 20, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 22, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 22, angle = 90, hjust = .5, vjust = .5, face = "plain"))

### FIGURE 6c) NPI-B-RP for t-test versus Cohen’s d 

ggplot(pairwise_data, aes(x=Cohen_d, y=NPI_B_RP_t,label=Compare)) + 
  geom_errorbar(aes(ymin=ytmin, ymax=ytmax), width=.1) +
  geom_point(size=1, shape=21, fill="white") + # 21 is filled circle
  xlab("Cohen's d") +
  ylab("NPI-B-RP") +
  xlim(-0.2,3.7)+
  scale_colour_hue(l=40) +                    # Use darker colors, lightness=40
  geom_text(hjust=-0.2, vjust=1.1,size=4)+# Use darker colors, lightness=40
  theme_bw()+
  theme(axis.text.x = element_text(color = "grey20", size = 20, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 20, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 22, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 22, angle = 90, hjust = .5, vjust = .5, face = "plain"))


### FIGURE 7: Comparing NPI-B-RP (minimal, mean and maximal) for t-test and WMT 
# First download data.frame needed for the figure:
pairwise_data_2_MAX<- data.frame("Pairwise" = c(1,2,3,4,5,1,2,3,4,5), "test" = c("t_test","t_test","t_test","t_test","t_test", "WMT","WMT","WMT","WMT","WMT"), "NPI_B_RP" = c(0.937,1.000,0.880,0.586,0.911,0.902,1.000,0.862,0.606,0.935), ymin = c(0.917,0.999,0.841,0.552,0.885,0.882,0.999,0.821,0.566,0.917), ymax = c(0.954,1.000,0.904,0.622,0.928,0.927,1.000,0.890,0.642,0.958), "Cohen_d" = c(2.041,3.213,1.753, 1.038,-0.115,2.041,3.213,1.753, 1.038,-0.115), "logged_pvalue" = c(-3.5584620, -6.2615366, -3.1279603, -1.7180581, -0.2235167,-3.5584620, -6.2615366, -3.1279603, -1.7180581, -0.2235167))#, stringsAsFactors = FALSE)

pd <- position_dodge(0.2) # move them .05 to the left and right

# Then, create a ggplot:
ggplot(pairwise_data_2_MAX, aes(x=factor(Pairwise), y=NPI_B_RP, colour=test)) + 
  geom_errorbar(aes(ymin=ymin, ymax=ymax), width=.1, position=pd) +
  geom_point(position=pd) +
  geom_point(position=pd, size=1, shape=21, fill="white") + # 21 is filled circle
  xlab("Pairwise comparison") +
  ylab("NPI-B-RP") +
  scale_colour_hue(name="Test",    # Legend label, use darker colors
                   breaks=c("t_test", "WMT"),
                   labels=c("t-test", "WMT"),
                   l=40) +                    # Use darker colors, lightness=40
  theme_bw() +
  theme(axis.text.x = element_text(color = "grey20", size = 15, angle = 00, hjust = .5, vjust = .5, face = "plain"),
        axis.text.y = element_text(color = "grey20", size = 15, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
        axis.title.x = element_text(color = "grey20", size = 18, angle = 0, hjust = .5, vjust = 0, face = "plain"),
        axis.title.y = element_text(color = "grey20", size = 18, angle = 90, hjust = .5, vjust = .5, face = "plain"),
        legend.title = element_text(color = "grey20", size = 14),
        legend.text = element_text(color = "grey20", size = 12),
        plot.title=element_text(color = "grey20", size = 14, angle = 0, hjust = .5, vjust = 0, face = "plain"))+
  theme(legend.justification=c(1,0),
        legend.position="bottom") +
  scale_x_discrete(labels=c("1"="A vs. B","2"="B vs. C","3"="C vs. D","4"="D vs. E","5"="E vs. F"))


