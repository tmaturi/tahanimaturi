######## This file presents R code for Algorithm 1 
#### presented in Section 3.1, in the article 'Statistical reproducibility for pairwise t-tests in pharmaceutical research'
#### First function calculated NPI-B-RP (via Algorithm 1) for the t-test
#### and the second function calculates NPI-B-RP for the WMT

#### The below function calculated NPI-B-RP for t-test
### This function is used in the simulation study (Section 3.2:  Figures 1, 2 and 3)
## and it is also applied to the pharmaceutical test scenario dataset 
# (Section 4.2: Table 2, Figures 6 and 7)
# the input into the function are datasets for dose 1 and dose 2,
# NPI-B-RP is calculated for the Students one-sided t-test (equal variance t-test) which compares whether the mean for dose 1 is bigger than for dose 2
reproducibility_t_test_finite_slow_max <- function(dose1,dose2) {
  dose1<- sort(dose1) # sort data in increasing order for dose 1
  n <- length(dose1) # calculate sample size of dose 1
  # Record all distances between adjacent points for dose 1
  max <- vector()
  for (k in (1:(n-1))) {
    max1 <- dose1[(k+1)] - dose1[k]
    max <- c(max,max1)
  }
  max_max <- max(max)  # Record maximal distance between adjacent points for dose 1
  
  dose2<- sort(dose2) # Sort data in increasing order for dose 2
  n2 <- length(dose2) # Calculate sample size of dose 2
  # Record all distances between adjacent points for dose 2
  max2 <- vector()
  for (k in (1:(n2-1))) {
    max_2 <- dose2[(k+1)] - dose2[k]
    max2 <- c(max2,max_2)
  }
  max_max2 <- max(max2) # Record maximal distance between adjacent points for dose 2
  
  so1 <-  min(dose1) - max_max # Defines x_0 for dose 1 
  sn1 <- max(dose1) + max_max # Defines x_{n+1} for dose 1
  so2 <-  min(dose2) - max_max2 # Defines x_0 for dose 2 
  sn2 <- max(dose2) + max_max2 # Defines x_{n+1} for dose 2
  
  one_times_step_finite_slow <- function(dose1,dose2,so1,sn1,so2,sn2) {  
    function_comparison_finite_slow <- function(dose1,dose2,so1,sn1,so2,sn2) { 
      # This function calculates p-value between 2 bootstrapped samples 
      
      finite_slow <- function(x, so, sn) { # This function creates one bootstrap sample
        m <- length(x)
        x <- append(x, c(so, sn), after =  length(x)) # add starting (x_0) and ending point (x_{n+1})
        x <- sort(x) # sort data in increasing order for the sample
        boot <- vector()
        for (j in 1:m){ # this cycle creates m new values from the original intervals
          int_1 <- length(x) - 1 
          jj<-sample(1:int_1,1,prob=rep(1/int_1,int_1))  # Sample an interval
          new_value <- runif(1, min = x[jj], max = x[jj+1]) # Sample a value in that interval ### takes time 
          x <- append(x, new_value, after = jj) # we add this sampled value to the set of values
          boot <- c(boot, new_value)
        } 
        return(t(boot))
      }
      
      x1 <- finite_slow(dose1,so1,sn1) # Create bootstrap sample for dose 1
      y1 <- finite_slow(dose2,so2,sn2) # Create bootstrap sample for dose 2
      
      return(t.test(x1,y1, alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value)  
      # calculate p-value between 2 bootstrapped samples
    }
    
    total <- sum(replicate(1000, function_comparison_finite_slow(dose1,dose2,so1,sn1,so2,sn2)) <=0.05) # Repeat 1000 (N) times Step 2 of Algorithm 1
    # The below calculates how many times we got the same decision as was the original decision
    if (t.test(dose1,dose2, alternative = "greater", paired = FALSE, var.equal = TRUE)$p.value < 0.05) {
      rp <- total/1000}
    else {rp <- 1 - total/1000}
    return(rp)
  }
  # The below line performs Steps 2-4 of Algorithm 1 h times
  output <-replicate(100, one_times_step_finite_slow(dose1, dose2, so1,sn1,so2,sn2))
  return(c(min(output),mean(output),max(output)))
}

#### The below function calculated NPI-B-RP for the WMT
### This function is used in the simulation study (Section 3.3: Figure 4)
## and it is also applied to the pharmaceutical test scenario dataset (Section 4.2: Table 2, Figure 7)
# the input into the function are datasets for dose 1 and dose 2,
# # NPI-B-RP is calculated for the one-sided WMT which compares whether the mean for dose 1 is bigger than for dose 2
reproducibility_Wilcoxon_finite_slow_max <- function(dose1,dose2) {
  dose1 <- sort(dose1) # sort data in increasing order for dose 1
  n <- length(dose1)  # calculate sample size of dose 1
  # Record all distances between adjacent points for dose 1
  max <- vector()
  for (k in (1:(n-1))) {
    max1 <- dose1[(k+1)] - dose1[k]
    max <- c(max,max1)
  }
  max_max <- max(max)  # Record maximal distance between adjacent points for dose 1
  
  dose2<- sort(dose2) # Sort data in increasing order for dose 2
  n2 <- length(dose2) # Calculate sample size of dose 2
  # Record all distances between adjacent points for dose 2
  max2 <- vector()
  for (k in (1:(n2-1))) {
    max_2 <- dose2[(k+1)] - dose2[k]
    max2 <- c(max2,max_2)
  }
  max_max2 <- max(max2) # Record maximal distance between adjacent points for dose 2
  
  so1 <-  min(dose1) - max_max # Defines x_0 for dose 1 
  sn1 <- max(dose1) + max_max # Defines x_{n+1} for dose 1
  so2 <-  min(dose1) - max_max2 # Defines x_0 for dose 2 
  sn2 <- max(dose1) + max_max2 # Defines x_{n+1} for dose 2
  
  one_times_step_finite_slow <- function(dose1,dose2,so1,sn1,so2,sn2) {  
    function_comparison_finite_slow <- function(dose1,dose2,so,sn,so2,sn2) { # CALCULATES P-VALUE BETWEENT 2 NEW BOOTSTRAPS
      # This function calculates p-value between 2 bootstrapped samples 
      
      finite_slow <- function(x, so, sn) { # This function creates one bootstrap sample
        m <- length(x)
        x <- append(x, c(so, sn), after =  length(x)) # add starting (x_0) and ending point (x_{n+1})
        x <- sort(x) # sort data in increasing order for the sample
        boot <- vector()
        for (j in 1:m){ # this cycle creates m new values from the original intervals
          int_1 <- length(x) - 1 
          jj<-sample(1:int_1,1,prob=rep(1/int_1,int_1))  # Sample an interval
          new_value <- runif(1, min = x[jj], max = x[jj+1]) # Sample a value in that interval 
          x <- append(x, new_value, after = jj) # we add this sampled value to the set of values
          boot <- c(boot, new_value)
        } 
        return(t(boot))
      }
      
      x1 <- finite_slow(dose1,so1,sn1) # Create bootstrap sample for dose 1
      y1 <- finite_slow(dose2,so2,sn2) # Create bootstrap sample for dose 2
      
      return(wilcox.test(x1,y1, alternative = "greater", paired = FALSE)$p.value)  
      # calculate p-value between 2 bootstrapped samples 
    }
    
    total <- sum(replicate(1000, function_comparison_finite_slow(dose1,dose2,so1,sn1,so2,sn2)) <=0.05) ### here is where the error occurs
    # The below calculates how many times we got the same decision as was the original decision
    
    if (wilcox.test(dose1,dose2, alternative = "greater", paired = FALSE)$p.value < 0.05) {
      rp <- total/1000}
    else {rp <- 1 - total/1000}
    return(rp)
  }
  # The below line performs Steps 2-4 of Algorithm 1 h times
  output <-replicate(100, one_times_step_finite_slow(dose1, dose2, so1,sn1,so2,sn2))
  return(c(min(output),mean(output),max(output)))
}
